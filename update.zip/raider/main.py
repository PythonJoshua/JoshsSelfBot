import discord, json, os, requests, datetime, time
from discord.ext import commands, tasks


print('RaidTOOL - github.com/PythonJoshua - youtube.com/c/JoshJS')

bot = commands.Bot(description="123Python", command_prefix="z;", self_bot=True)
await bot.change_presence(status=discord.Status.idle, activity=discord.Activity(type=discord.ActivityType.playing, name="Minecraft"))
bot.remove_command("help")

@bot.command()
async def help(ctx):
  embed = discord.Embed(color=0x5CDBF0)
  embed.set_author(name="RaidToolˢᵇ - Privateˢᵇ ")
  embed.add_field(name="z;help", value="Shows This Command")
  embed.add_field(name="z;destroy", value="Shreds a discord server into 2 pieces, both being destroyed.")
  embed.add_field(name="z;status", value="Shows you the Tablist of 2b2t, the TPS, the player count, and the uptime.")
  embed.add_field(name="z;dmall", value="DMs all users in a guild.")
  embed.add_field(name="z;invpurge", value="Purges/Clears all invites.")
  embed.add_field(name="z;adminall", value="Gives admin to all users in a guild")
  embed.add_field(name="z;banall", value="Bans all users in a guild.")
  embed.set_footer(text="©2021 RaidToolˢᵇ - youtube.com/c/JoshJS - github.com/PythonJoshua")
  await ctx.send(embed=embed)

@bot.command()
async def dmall(ctx, *, message):
        await ctx.message.delete()
        for user in ctx.guild.members:
            try:
                await user.send(message)
                print(f"{user.name} has recieved the message.")
            except:
                print(f"{user.name} has NOT recieved the message.")
        print("Action Completed: Mass DM")

@bot.command()
async def adminall(ctx):
  await ctx.message.delete()
  for role in list(ctx.guild.roles):
             if role.name == '@everyone':
                  try:
                      await role.edit(permissions=Permissions.all())
                      print("@everyone has admin") 
                  except:
                      print("@everyone does NOT have admin")

 @bot.command(aliases=["delinvites"])
    async def invpurge(self, ctx):
        await ctx.send(f"Delete every invite in `{ctx.guild.name}`? [y/n]")

        def check_data(message):
            return message.author == ctx.message.author

        while True:
            try:
                msg = await self.bot.wait_for('message', check=check_data, timeout=int(timeout))
                if msg.content == "y":
                    await ctx.send(waitmsg)
                    for invite in await ctx.guild.invites():
                        try:
                            await invite.delete()
                        except Exception:
                            pass
                    await ctx.send(donemsg)
                    return
                if msg.content == "n":
                    await ctx.send(no_msg)
                    return
            except asyncio.TimeoutError:
                await ctx.send(timeout_msg)
                return

@bot.command(aliases=["allban"])
    async def banall(self, ctx):
        await ctx.send(f"Ban everyone out of `{ctx.guild.name}`? [y/n]")

        def check_data(message):
            return message.author == ctx.message.author

        while True:
            try:
                msg = await self.bot.wait_for('message', check=check_data, timeout=int(timeout))
                if msg.content == "y":
                    await ctx.send(waitmsg)
                    for user in ctx.guild.members:
                        try:
                            await ctx.guild.ban(user)
                        except Exception:
                            pass
                    await ctx.send(donemsg)
                    return
                if msg.content == "n":
                    await ctx.send(no_msg)
                    return
            except asyncio.TimeoutError:
                await ctx.send(timeout_msg)
                return

with open('./config.json') as f:
    config = json.load(f)

token = config.get('token')
bot.run(token, bot=False)